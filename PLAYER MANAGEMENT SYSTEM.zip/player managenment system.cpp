
//*Problem Statement:

/*A Player Management System is required to efficiently organize and manage 
information about cricket players. The system should support various 
operations, including adding, removing, searching, updating, displaying all 
player records, and showcasing the top 3 players based on runs and wickets. 
The system should handle player attributes, including Jersey Number, Name, 
Runs, Wickets, and Matches played.*/
using namespace std;
#include<iostream>
#include <string.h>


 struct Player
{
	int jerseynumber;
	char name[40];
	int runs;
	int wickets;
	int matchesplayed;
	
	 //Default constructor
	 Player()
	 {
	 	this->jerseynumber=0;
	 	strcpy(this->name,"not given");
	 	this->runs=0;
	 	this->wickets=0;
	 	this->matchesplayed=0;
	 }
	 //parameterized constructor
	Player(int a,char* b,int c,int d,int e)
	 {
	 	this->jerseynumber=a;
	 	strcpy(this->name,b);
	 	this->runs=c;
	 	this->wickets=d;
	 	this->matchesplayed=e;
	 }
	 
	 //setter for jerseynumber
	 void setjerseynumber(int a)
	 {
	 this->jerseynumber=a;
	 }
	 //getter for jerseynumber
	 int getjerseynumber()
	 {
	 	return this->jerseynumber;
	 }
	 //setter for name
	 void setname(char* b)
	 {
	 strcpy(this->name,b);
	 }
	 //getter for name
	 char* getname()
	 {
	 	return this->name;
	 }
	  //setter for runs
	 void setruns(int c)
	 {
	 this->runs=c;
	 }
	 //getter for runs
	 int getruns()
	 {
	 	return  this->runs;
	 }
	 //setter for wickets
	 void setwickets(int d)
	 {
	 this->wickets=d;
	 }
	 //getter for wickets
	 int getwickets()
	 {
	 	return  this->wickets;
	 }
	 //setter for matchesplayed
	 void setmatchesplayed(int e)
	 {
	 this->matchesplayed=e;
	 }
	 //getter for matchesplayed
	 int getmatchesplayed()
	 {
	 	return  this->matchesplayed;
	 }
	 void display()
	{
//		
//	{
//		cout<<"          //No players in database.\\\n";
//		return;
//		}
			cout<<"          \n**Available players list**\n";
			cout<<"\n-----------------------------------------------------------------------------------";
			cout<<"\n|  Jersey number  |    Name    |  Total runs  |  Total Wickets  |  Total Matches  |";
			cout<<"\n-----------------------------------------------------------------------------------";
			cout<<"\n|"<<"\t"<< this->jerseynumber<<"\t"<<"|"<<"\t"<<this->name<<"\t"<<"|"<<"\t"<<this->runs<<"\t"<<"|"<<"\t"<<this->wickets<<"\t"<<"|"<<"\t"<<this->matchesplayed<<"\t"<<"|";        
		    cout<<"\n-----------------------------------------------------------------------------------";
}
//		cout<<"\njerseynumber :"<<this->jerseynumber;
//		cout<<"\nname :"<<this->name;
//		cout<<"\nruns :"<<this->runs;
//		cout<<"\nwickets:"<<this->wickets;
//		cout<<"\nmatchesplayed :"<<this->matchesplayed;

	 
	 
};

void addplayer(Player*,int*);
void displayallplayer(Player*,int);
void displaytop3runs(Player*,int);
void displaytop3wickets(Player*,int);
void searchbyjerseyno(Player*,int,int);
void searchbyname(Player*,int,char*);
void updateplayerdata(Player*,int,int,int,int,int);
void removeplayer(Player*,int*,int);

int main()
{
	int choice;
		Player playerlist[300];
	int n;	
	int *a;
    //a=(int*)malloc(sizeof(int)*n);
    a=new int[n];
cout<<"\n //////////////////////////////";
cout<<"\n ** PLAYER MANAGEMENT SYSTEM **";
cout<<"\n //////////////////////////////";
	while(1)
	{
	cout<<"\n1. Add Player\n";
        cout<<"2. Display All Players\n";
        cout<<"3. Display Top 3 Players \n";
        cout<<"4. Search Player\n";
       cout<<"5. Update Player\n";
        cout<<"6. Remove Player\n";
        cout<<"7. Exit\n";
       cout<<"Enter your choice: ";
	cin>>choice;
	

	switch (choice)
	{
	
	case 1:
		 
   
					addplayer(playerlist,&n);
//					for(int a=0;a<n;a++)
//					 {
//					 	 playerlist[a].display(n);
//					 }
					
		break;
		
		case 2:	
//			Player *ply;
//		ply=new Player();
//		ply=display();
		         	//displayallplayer(playerlist,n);
		         	cout<<"          //No players in database.\\ \n";
		         	for(int a=0;a<n;a++)
					 {
					 	playerlist[a].display();
					 }
		        
        break;
		int searchchoice;
		
		case 3:
			
			
		cout<<"\n**Enter the choice**";
		cout<<"\n1. Top 3 player Depends on Runs ";
			cout<<"\n2.Top 3 player Depends on Wickets ";
			 cout<<"\n3. Exit\n";
			 cout<<"Enter a search by choice: ";
	cin>>searchchoice;
			switch(searchchoice)
			{
				case 1:
					
 displaytop3runs(playerlist,n);
         break;
                case 2:
                
	displaytop3wickets(playerlist,n);
}
	    break;
default:
			cout<<"/n invalid choice";
		
        break;
		
		
		int searchachoice;
		case 4:
		
		
		cout<<"\n**Enter the choice**";
		cout<<"\n1. For search by jersey number ";
			cout<<"\n2. For search by name ";
			 cout<<"\n3. Exit\n";
			 cout<<"Enter a search by choice: ";
cin>>searchachoice;
			switch(searchachoice)
			{
					int searchjerseynumber;
				case 1:
						cout<<"\nEnter the jersey no of player for search:";
		cin>>searchjerseynumber;
 searchbyjerseyno(playerlist,n,searchjerseynumber);
         break;
 
 	char searchname[10];
                case 2:
                	cout<<"\nEnter the name of player for search:";
		cin>>searchname;
	searchbyname(playerlist,n,searchname);
	    break;
	    
	default:
			cout<<"/n invalid choice";
                	
		
		}

break;

     int jerseynumber;
	 int newruns;
	 int newwickets;
	 int newmatchesplayed;  
case 5:
			cout<<"\nEnter the jersey number of player you want to update details:";
			cin>>jerseynumber;
			cout<<"\n Enter the Updated Runs :";
		cin>>newruns;
			cout<<"\n Enter the Updated Wickets :";
			cin>>newwickets;
				cout<<"\n Enter the Updated Matches Played :\n";
			cin>>newmatchesplayed;
	updateplayerdata(playerlist,n,jerseynumber,newruns,newwickets,newmatchesplayed);
break;
		int removeaplayer;
		
		case 6:	
		cout<<"Enter the jersey no you want to remove :";
		cin>>removeaplayer;
   removeplayer(playerlist,&n,removeaplayer);
   
break;  
             
	case 7:	
  cout<<"      *****THANKYOU TO USE PLAYER MANAGEMENT SYSTEM*****";
   
break;  
 
	}
	
}
return 0;	

}
	void addplayer(Player* p ,int* n)
	{                       
cout<<"\nEnter the no of players :";
cin >>*n;
		for(int i=0;i<*n;i++)
		{        
			cout<<"\nEnter the jersey number :";
			cin>>p[i].jerseynumber ;
			cout<<"\nEnter the player name :";
			cin>>p[i].name ;
			cout<<"\nEnter the runs :";
			cin>>p[i].runs;
			cout<<"\nEnter the no of Wicket taken by player :";
			cin>>p[i].wickets;
			cout<<"\nEnter the on of matches played by player :";
			cin>>p[i].matchesplayed;
			cout<<"        **CONGRATULATION**\n PLAYER ADDED SUCCESSFULLY ";
					
		}	
	}
//	void displayallplayer(Player* p,int n)
//	{
//	if(n==0)
//	{
//		cout<<"          //No players in database.\\\n";
//		return;
//		}
//			cout<<"          **Available players list**\n";
//			cout<<"\n-----------------------------------------------------------------------------------";
//			cout<<"\n|  Jersey number  |    Name    |  Total runs  |  Total Wickets  |  Total Matches  |";
//			cout<<"\n-----------------------------------------------------------------------------------";
//		
//		for(int i=0;i<n;i++)
//		{
//			cout<<"\n|"<<p[i].jerseynumber<<"|"<<p[i].name<<"|"<<p[i].runs<<"|"<<p[i].wickets <<"|"<<p[i].matchesplayed;        
//		    cout<<"\n-----------------------------------------------------------------------------------";
//}
//	}
void displaytop3runs(Player* p, int n)
{
    if (n < 3) 
    {
        	cout<<"Sorry, at least 3 player data are required for this operation.\n";
        return;
    }

    for (int i = 0; i < n - 1; i++) 
    {
        for (int j = 0; j < n - i - 1; j++) 
        {
            if (p[j].runs < p[j + 1].runs) 
            {
                Player temp = p[j];
                p[j] = p[j + 1];
                p[j + 1] = temp;
            }
        }
    }

   	cout<<"TOP 3 Players Depende On Runs:\n";
    for (int i = 0; i < 3; i++) 
    {
    	p[i].display();
//        	cout<<"\nJersey number: "<< p[i].jerseynumber;
//        	cout<<"\nName: "<<p[i].name;
//       	cout<<"\nTotal runs: "<< p[i].runs;
//        	cout<<"\nTotal Wickets: "<< p[i].wickets;
//       	cout<<"\nTotal Matches: "<<p[i].matchesplayed;
    }
}

void displaytop3wickets(Player* p, int n)
{
    if (n < 3) 
    {
        	cout<<"\nSorry, at least 3 player data are required for this operation.\n";
        return;
    }

    for (int i = 0; i < n - 1; i++) 
    {
        for (int j = 0; j < n - i - 1; j++) 
        {
            if (p[j].wickets < p[j + 1].wickets) 
            {
                Player temp = p[j];
                p[j] = p[j + 1];
                p[j + 1] = temp;
            }
        }
    }

    	cout<<"TOP 3 Players Depende On Wickets:\n";
    for (int i = 0; i < 3; i++) 
    {
    		p[i].display();
//        	cout<<"\nJersey number: "<< p[i].jerseynumber;
//       	cout<<"\nName: "<< p[i].name;
//        	cout<<"\nTotal runs: "<< p[i].runs;
//        	cout<<"\nTotal Wickets: "<< p[i].wickets;
//       	cout<<"\nTotal Matches: "<< p[i].matchesplayed;
    }
}

	
void searchbyjerseyno(Player *p,int n,int searchjerseynumber)
{
	for(int i=0;i<n;i++)
	{
		if(p[i].jerseynumber==searchjerseynumber)
		{
				cout<<"**\nplayer found**\n";
					p[i].display();
//					cout<<"\nJersey number :"<<p[i].jerseynumber;
//			cout<<"\nName :"<<p[i].name ;
//			cout<<"\nTotal runs :"<<p[i].runs;
//		cout<<"\nTotal Wickets :"<<p[i].wickets;
//			cout<<"\nTotal Matches :"<<p[i].matchesplayed;
		return ;
		}
	}
		cout<<"player jersey  number not found :"<<searchjerseynumber;
}
void searchbyname(Player *p,int n,char* searchname)
{
	int found=0;
	
	for(int i=0;i<n;i++)
	{
		if(stricmp(p[i].name,searchname)==0)
		{
				cout<<"**\nplayer found**\n";
					p[i].display();
//					cout<<"\nJersey number :"<<p[i].jerseynumber;
//			cout<<"\nName :"<<p[i].name ;
//		cout<<"\nTotal runs :"<<p[i].runs;
//			cout<<"\nTotal Wickets :"<<p[i].wickets;
//			cout<<"\nTotal Matches :"<<p[i].matchesplayed;
		found=1;
		}
	}
	if (found==0)
		cout<<"\nplayer jersey  number not found"<<searchname;
}
void updateplayerdata(Player* p, int n, int jerseynumber, int newruns, int newwickets, int newmatchesplayed)
{
    int found = 0;
    for (int i = 0; i < n; i++) 
    {
        if (p[i].jerseynumber == jerseynumber) 
        {
            p[i].runs = newruns;
            p[i].wickets = newwickets;
            p[i].matchesplayed = newmatchesplayed;
            found = 1;
           	cout<<"\nPlayer with jersey number has been updated."<< jerseynumber;
            break;
        }
    }

    if (found == 0) 
    {
        	cout<<"\nPlayer with jersey number not found in the library. Update failed."<< jerseynumber;
    }
}
void removeplayer(Player* p, int* n, int removeaPlayer)
 {
    int found = 0;

    for (int i = 0; i < *n; i++)
	 {
        if (p[i].jerseynumber == removeaPlayer)
		 {
            for (int j = i; j < *n - 1 ; j++) 
			{
                p[j] = p[j + 1];
            }
            (*n)--;
            found = 1;
           	cout<<"\nPlayer with jersey number has been removed successfully."<< removeaPlayer;
            break;
        }
    }

    if (found == 0)
	 {
       	cout<<"\nPlayer with jersey number not found."<< removeaPlayer;
    }
}

	